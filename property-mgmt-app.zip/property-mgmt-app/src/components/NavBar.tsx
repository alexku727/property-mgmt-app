'use client';
import Link from 'next/link';
import { signOut, useSession } from 'next-auth/react';

export function NavBar() {
  const { data } = useSession();
  const user = data?.user as any;
  const role = user?.role;
  return (
    <header className="bg-white border-b">
      <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
        <Link href="/" className="font-bold text-brand">Property Mgmt</Link>
        <nav className="flex items-center gap-4 text-sm">
          {role === 'ADMIN' && (
            <>
              <Link href="/admin">Dashboard</Link>
              <Link href="/admin/schedule">Schedule</Link>
              <Link href="/admin/workers">Workers</Link>
              <Link href="/admin/properties">Properties</Link>
              <Link href="/admin/billing">Billing</Link>
            </>
          )}
          {(role === 'CLEANER' || role === 'PORTER') && <Link href="/worker">My Schedule</Link>}
          {role === 'OWNER' && <Link href="/owner">My Invoices</Link>}
          {user && (
            <button onClick={() => signOut({ callbackUrl: '/login' })} className="text-slate-600 hover:text-slate-900">
              Sign out ({user.name})
            </button>
          )}
        </nav>
      </div>
    </header>
  );
}
