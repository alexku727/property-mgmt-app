'use client';
import { useEffect, useState } from 'react';

export function ClockButton({ taskId }: { taskId?: string }) {
  const [open, setOpen] = useState<{ id: string; clockIn: string } | null>(null);
  const [busy, setBusy] = useState(false);

  async function refresh() {
    const r = await fetch('/api/timeentries');
    const j = await r.json();
    const cur = (j as any[]).find(e => !e.clockOut);
    setOpen(cur ? { id: cur.id, clockIn: cur.clockIn } : null);
  }
  useEffect(() => { refresh(); }, []);

  async function toggle(action: 'in' | 'out') {
    setBusy(true);
    let coords: GeolocationCoordinates | null = null;
    try {
      if ('geolocation' in navigator) {
        coords = await new Promise<GeolocationCoordinates>((res, rej) =>
          navigator.geolocation.getCurrentPosition(p => res(p.coords), rej, { timeout: 4000 })
        ).catch(() => null);
      }
    } catch {}
    await fetch('/api/timeentries/clock', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action, taskId, lat: coords?.latitude, lng: coords?.longitude })
    });
    setBusy(false);
    refresh();
  }

  return (
    <div className="flex items-center gap-3">
      {open ? (
        <>
          <span className="text-sm text-slate-700">
            Clocked in at {new Date(open.clockIn).toLocaleTimeString()}
          </span>
          <button disabled={busy} onClick={() => toggle('out')} className="bg-red-600 text-white px-4 py-2 rounded disabled:opacity-60">
            {busy ? '…' : 'Clock out'}
          </button>
        </>
      ) : (
        <button disabled={busy} onClick={() => toggle('in')} className="bg-emerald-600 text-white px-4 py-2 rounded disabled:opacity-60">
          {busy ? '…' : 'Clock in'}
        </button>
      )}
    </div>
  );
}
