'use client';
import { useEffect, useState, useCallback } from 'react';
import { weekRange, dayLabels } from '@/lib/dates';
import { addDays, format, isSameDay } from 'date-fns';

type Task = {
  id: string;
  title: string;
  type: string;
  status: string;
  scheduledFor: string;
  estimatedMin: number | null;
  property: { id: string; name: string };
  unit: { id: string; label: string } | null;
  assignedTo: { id: string; name: string; role: string } | null;
};

type Worker = { id: string; name: string; role: 'CLEANER' | 'PORTER' };

export function Calendar({ canEdit }: { canEdit: boolean }) {
  const [anchor, setAnchor] = useState<Date>(new Date());
  const [tasks, setTasks] = useState<Task[]>([]);
  const [workers, setWorkers] = useState<Worker[]>([]);
  const [loading, setLoading] = useState(false);
  const { start } = weekRange(anchor);
  const days = dayLabels(start);

  const reload = useCallback(async () => {
    setLoading(true);
    const r = await fetch(`/api/schedule?anchor=${anchor.toISOString()}`);
    const j = await r.json();
    setTasks(j.tasks ?? []);
    setLoading(false);
  }, [anchor]);

  useEffect(() => { reload(); }, [reload]);
  useEffect(() => {
    if (canEdit) fetch('/api/workers').then(r => r.json()).then(setWorkers).catch(() => {});
  }, [canEdit]);

  async function assign(taskId: string, workerId: string) {
    await fetch(`/api/tasks/${taskId}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ assignedToId: workerId || null })
    });
    reload();
  }

  async function reschedule(taskId: string, newDate: Date) {
    await fetch(`/api/tasks/${taskId}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ scheduledFor: newDate.toISOString() })
    });
    reload();
  }

  async function remove(taskId: string) {
    if (!confirm('Delete this task?')) return;
    await fetch(`/api/tasks/${taskId}`, { method: 'DELETE' });
    reload();
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <div className="flex gap-2">
          <button className="px-3 py-1 border rounded" onClick={() => setAnchor(addDays(anchor, -7))}>← Prev</button>
          <button className="px-3 py-1 border rounded" onClick={() => setAnchor(new Date())}>This week</button>
          <button className="px-3 py-1 border rounded" onClick={() => setAnchor(addDays(anchor, 7))}>Next →</button>
        </div>
        <div className="text-sm text-slate-600">
          {format(start, 'MMM d')} – {format(addDays(start, 6), 'MMM d, yyyy')}
          {loading && ' (loading…)'}
        </div>
      </div>

      <div className="grid grid-cols-7 gap-2">
        {days.map(d => {
          const dayTasks = tasks.filter(t => isSameDay(new Date(t.scheduledFor), d.date));
          return (
            <div key={d.label} className="bg-white rounded shadow-sm min-h-[160px] flex flex-col">
              <div className="px-2 py-1 border-b text-xs font-semibold text-slate-600">{d.label}</div>
              <div className="p-2 flex-1 space-y-1">
                {dayTasks.length === 0 && <div className="text-xs text-slate-400">—</div>}
                {dayTasks.map(t => (
                  <div key={t.id} className={`text-xs rounded px-2 py-1 border-l-4 ${
                    t.type === 'CLEANING' ? 'border-blue-500 bg-blue-50'
                    : t.type === 'PORTER' ? 'border-emerald-500 bg-emerald-50'
                    : 'border-slate-400 bg-slate-50'}`}>
                    <div className="font-medium truncate">{t.title}</div>
                    <div className="text-slate-600 truncate">{t.property.name}{t.unit ? ` • ${t.unit.label}` : ''}</div>
                    <div className="text-slate-500">
                      {format(new Date(t.scheduledFor), 'h:mm a')} • {t.status}
                    </div>
                    {canEdit ? (
                      <div className="mt-1 flex flex-wrap gap-1">
                        <select
                          className="text-xs border rounded px-1 py-0.5 max-w-full"
                          value={t.assignedTo?.id ?? ''}
                          onChange={e => assign(t.id, e.target.value)}
                        >
                          <option value="">Unassigned</option>
                          {workers.map(w => (
                            <option key={w.id} value={w.id}>{w.name} ({w.role})</option>
                          ))}
                        </select>
                        <input
                          type="datetime-local"
                          className="text-xs border rounded px-1 py-0.5"
                          defaultValue={format(new Date(t.scheduledFor), "yyyy-MM-dd'T'HH:mm")}
                          onBlur={e => {
                            const nd = new Date(e.target.value);
                            if (!isNaN(nd.getTime())) reschedule(t.id, nd);
                          }}
                        />
                        <button onClick={() => remove(t.id)} className="text-red-600 text-xs">✕</button>
                      </div>
                    ) : (
                      <div className="text-slate-500 mt-0.5">{t.assignedTo?.name ?? 'Unassigned'}</div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
