import Link from 'next/link';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { redirect } from 'next/navigation';

export default async function Home() {
  const session = await getServerSession(authOptions);
  if (session) {
    const role = (session.user as any).role;
    if (role === 'ADMIN') redirect('/admin');
    if (role === 'OWNER') redirect('/owner');
    redirect('/worker');
  }
  return (
    <main className="min-h-screen flex items-center justify-center">
      <div className="bg-white rounded-xl shadow p-8 w-full max-w-md text-center">
        <h1 className="text-2xl font-bold mb-2">Property Mgmt</h1>
        <p className="text-slate-600 mb-6">Scheduling • Time Tracking • Billing</p>
        <Link href="/login" className="inline-block bg-brand text-white px-4 py-2 rounded hover:bg-brand-dark">
          Sign in
        </Link>
      </div>
    </main>
  );
}
