import { prisma } from '@/lib/prisma';
import { Role } from '@prisma/client';

export default async function WorkersPage() {
  const workers = await prisma.user.findMany({
    where: { role: { in: [Role.CLEANER, Role.PORTER] } },
    orderBy: { name: 'asc' },
    include: { timeEntries: { orderBy: { clockIn: 'desc' }, take: 1 }, assignedTasks: true }
  });
  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Workers</h1>
      <table className="w-full bg-white rounded shadow-sm text-sm">
        <thead className="text-left border-b">
          <tr><th className="p-2">Name</th><th className="p-2">Role</th><th className="p-2">Email</th><th className="p-2">Last clock</th><th className="p-2">Open tasks</th></tr>
        </thead>
        <tbody>
          {workers.map(w => {
            const last = w.timeEntries[0];
            const open = w.assignedTasks.filter(t => t.status !== 'COMPLETED' && t.status !== 'CANCELLED').length;
            return (
              <tr key={w.id} className="border-b last:border-0">
                <td className="p-2">{w.name}</td>
                <td className="p-2">{w.role}</td>
                <td className="p-2">{w.email}</td>
                <td className="p-2">{last ? new Date(last.clockIn).toLocaleString() : '—'}</td>
                <td className="p-2">{open}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
      <p className="text-sm text-slate-500 mt-4">
        To add a new worker, run <code>npm run db:seed</code> with a custom seed or insert directly via Prisma Studio (<code>npx prisma studio</code>).
      </p>
    </div>
  );
}
