import { prisma } from '@/lib/prisma';

export default async function AdminDashboard() {
  const [taskCount, openInvoices, lastRuns] = await Promise.all([
    prisma.task.count(),
    prisma.invoice.count({ where: { status: { in: ['SENT', 'OVERDUE'] } } }),
    prisma.syncRun.findMany({ orderBy: { startedAt: 'desc' }, take: 4 })
  ]);
  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Dashboard</h1>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
        <Card title="Tasks (total)" value={taskCount} />
        <Card title="Open invoices" value={openInvoices} />
        <Card title="Last sync" value={lastRuns[0]?.startedAt ? new Date(lastRuns[0].startedAt).toLocaleString() : 'never'} />
      </div>
      <h2 className="font-semibold mb-2">Sync history</h2>
      <table className="w-full bg-white rounded shadow-sm text-sm">
        <thead className="text-left text-slate-600 border-b">
          <tr><th className="p-2">When</th><th className="p-2">Source</th><th className="p-2">Items</th><th className="p-2">Status</th></tr>
        </thead>
        <tbody>
          {lastRuns.map(r => (
            <tr key={r.id} className="border-b last:border-0">
              <td className="p-2">{new Date(r.startedAt).toLocaleString()}</td>
              <td className="p-2">{r.source}</td>
              <td className="p-2">{r.itemsUpserted}</td>
              <td className="p-2">{r.ok ? '✓' : `✗ ${r.errorText ?? ''}`}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <div className="mt-6 flex gap-2">
        <form action="/api/sync/rentmanager" method="post">
          <button className="bg-brand text-white px-3 py-2 rounded">Sync Rent Manager</button>
        </form>
        <form action="/api/sync/bookingkoala" method="post">
          <button className="bg-brand text-white px-3 py-2 rounded">Sync BookingKoala</button>
        </form>
      </div>
    </div>
  );
}

function Card({ title, value }: { title: string; value: any }) {
  return (
    <div className="bg-white rounded-xl shadow-sm p-4">
      <div className="text-xs uppercase text-slate-500">{title}</div>
      <div className="text-2xl font-bold mt-1">{String(value)}</div>
    </div>
  );
}
