import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { redirect } from 'next/navigation';
import { NavBar } from '@/components/NavBar';

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const session = await getServerSession(authOptions);
  if (!session) redirect('/login');
  if ((session.user as any).role !== 'ADMIN') redirect('/');
  return (
    <>
      <NavBar />
      <main className="max-w-7xl mx-auto px-4 py-6">{children}</main>
    </>
  );
}
