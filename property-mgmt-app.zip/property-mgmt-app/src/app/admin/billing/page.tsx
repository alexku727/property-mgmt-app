'use client';
import { useEffect, useState } from 'react';

type Invoice = {
  id: string; number: string; status: string;
  totalCents: number; issuedAt: string;
  owner: { name: string; email: string };
  property?: { name: string } | null;
};

type Owner = { id: string; name: string; email: string };
type Task = { id: string; title: string; scheduledFor: string; property: { name: string; ownerId?: string | null }; estimatedMin: number | null; rate: number | null };

export default function AdminBillingPage() {
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [owners, setOwners] = useState<Owner[]>([]);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [selOwner, setSelOwner] = useState<string>('');
  const [selTasks, setSelTasks] = useState<Set<string>>(new Set());

  async function reload() {
    const i = await fetch('/api/billing/invoices').then(r => r.json());
    setInvoices(i);
  }
  useEffect(() => { reload(); }, []);
  useEffect(() => {
    fetch('/api/tasks').then(r => r.json()).then((rows: any[]) => {
      setTasks(rows.filter(t => t.status === 'COMPLETED'));
      const map = new Map<string, Owner>();
      rows.forEach((t: any) => {
        if (t.property?.owner) map.set(t.property.owner.id, t.property.owner);
      });
      setOwners(Array.from(map.values()));
    });
  }, []);

  async function createInvoice() {
    if (!selOwner || selTasks.size === 0) return alert('Pick an owner + at least one completed task');
    const res = await fetch('/api/billing/invoices', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ownerId: selOwner, taskIds: Array.from(selTasks) })
    });
    if (!res.ok) return alert('Failed: ' + (await res.text()));
    setSelTasks(new Set());
    reload();
  }

  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Billing</h1>

      <div className="bg-white rounded shadow-sm p-4 mb-6">
        <h2 className="font-semibold mb-2">Create invoice from completed tasks</h2>
        <div className="flex flex-wrap gap-2 items-center mb-3">
          <select value={selOwner} onChange={e => setSelOwner(e.target.value)} className="border rounded px-2 py-1">
            <option value="">— Pick owner —</option>
            {owners.map(o => <option key={o.id} value={o.id}>{o.name} ({o.email})</option>)}
          </select>
          <button onClick={createInvoice} className="bg-brand text-white px-3 py-2 rounded">Create invoice</button>
        </div>
        <div className="max-h-64 overflow-auto border rounded text-sm">
          {tasks.length === 0 && <div className="p-3 text-slate-500">No completed tasks ready to invoice.</div>}
          {tasks.map(t => (
            <label key={t.id} className="flex items-center gap-2 p-2 border-b last:border-0">
              <input type="checkbox" checked={selTasks.has(t.id)} onChange={e => {
                const ns = new Set(selTasks);
                e.target.checked ? ns.add(t.id) : ns.delete(t.id);
                setSelTasks(ns);
              }} />
              <span>{t.title} — {t.property.name} — {new Date(t.scheduledFor).toLocaleDateString()} — {t.estimatedMin ?? '?'}m @ ${t.rate ?? 0}/hr</span>
            </label>
          ))}
        </div>
      </div>

      <h2 className="font-semibold mb-2">Invoices</h2>
      <table className="w-full bg-white rounded shadow-sm text-sm">
        <thead className="text-left border-b">
          <tr><th className="p-2">#</th><th className="p-2">Owner</th><th className="p-2">Property</th><th className="p-2">Issued</th><th className="p-2">Total</th><th className="p-2">Status</th></tr>
        </thead>
        <tbody>
          {invoices.map(inv => (
            <tr key={inv.id} className="border-b last:border-0">
              <td className="p-2 font-mono">{inv.number}</td>
              <td className="p-2">{inv.owner.name}</td>
              <td className="p-2">{inv.property?.name ?? '—'}</td>
              <td className="p-2">{new Date(inv.issuedAt).toLocaleDateString()}</td>
              <td className="p-2">${(inv.totalCents / 100).toFixed(2)}</td>
              <td className="p-2">{inv.status}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
