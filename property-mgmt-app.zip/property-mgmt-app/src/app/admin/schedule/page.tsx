'use client';
import { Calendar } from '@/components/Calendar';
import { useEffect, useState } from 'react';

type Property = { id: string; name: string };
type Worker = { id: string; name: string; role: 'CLEANER' | 'PORTER' };

export default function AdminSchedulePage() {
  const [showNew, setShowNew] = useState(false);
  const [properties, setProperties] = useState<Property[]>([]);
  const [workers, setWorkers] = useState<Worker[]>([]);

  useEffect(() => {
    fetch('/api/workers').then(r => r.json()).then(setWorkers).catch(() => {});
    // simple inline property fetch
    fetch('/api/tasks').then(r => r.json()).then((rows: any[]) => {
      const map = new Map<string, Property>();
      rows.forEach(t => map.set(t.property.id, { id: t.property.id, name: t.property.name }));
      setProperties(Array.from(map.values()));
    });
  }, []);

  async function create(form: FormData) {
    await fetch('/api/tasks', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        type: form.get('type'),
        title: form.get('title'),
        propertyId: form.get('propertyId'),
        scheduledFor: new Date(form.get('scheduledFor') as string).toISOString(),
        estimatedMin: Number(form.get('estimatedMin') || 60),
        assignedToId: (form.get('assignedToId') as string) || undefined,
        rate: Number(form.get('rate') || 0)
      })
    });
    setShowNew(false);
    location.reload();
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h1 className="text-2xl font-bold">Weekly schedule</h1>
        <button onClick={() => setShowNew(s => !s)} className="bg-brand text-white px-3 py-2 rounded">
          {showNew ? 'Cancel' : '+ New task'}
        </button>
      </div>

      {showNew && (
        <form onSubmit={e => { e.preventDefault(); create(new FormData(e.currentTarget)); }}
          className="bg-white rounded shadow-sm p-4 mb-4 grid grid-cols-2 md:grid-cols-3 gap-3 text-sm">
          <label>Title<input name="title" required className="border rounded w-full px-2 py-1" /></label>
          <label>Type
            <select name="type" required className="border rounded w-full px-2 py-1">
              <option value="CLEANING">CLEANING</option>
              <option value="PORTER">PORTER</option>
              <option value="MAINTENANCE">MAINTENANCE</option>
              <option value="OTHER">OTHER</option>
            </select>
          </label>
          <label>Property
            <select name="propertyId" required className="border rounded w-full px-2 py-1">
              {properties.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
            </select>
          </label>
          <label>Scheduled<input type="datetime-local" name="scheduledFor" required className="border rounded w-full px-2 py-1" /></label>
          <label>Est. minutes<input type="number" name="estimatedMin" defaultValue={60} className="border rounded w-full px-2 py-1" /></label>
          <label>Assign to
            <select name="assignedToId" className="border rounded w-full px-2 py-1">
              <option value="">— Unassigned —</option>
              {workers.map(w => <option key={w.id} value={w.id}>{w.name} ({w.role})</option>)}
            </select>
          </label>
          <label>Rate ($/hr)<input type="number" step="0.01" name="rate" defaultValue={45} className="border rounded w-full px-2 py-1" /></label>
          <div className="col-span-full">
            <button className="bg-brand text-white px-4 py-2 rounded">Create</button>
          </div>
        </form>
      )}

      <Calendar canEdit />
    </div>
  );
}
