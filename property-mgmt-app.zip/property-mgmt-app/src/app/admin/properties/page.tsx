import { prisma } from '@/lib/prisma';

export default async function PropertiesPage() {
  const properties = await prisma.property.findMany({
    include: { units: true, owner: { select: { name: true, email: true } }, _count: { select: { tasks: true } } },
    orderBy: { name: 'asc' }
  });
  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Properties</h1>
      <table className="w-full bg-white rounded shadow-sm text-sm">
        <thead className="text-left border-b">
          <tr><th className="p-2">Name</th><th className="p-2">Address</th><th className="p-2">Units</th><th className="p-2">Owner</th><th className="p-2">Tasks</th></tr>
        </thead>
        <tbody>
          {properties.map(p => (
            <tr key={p.id} className="border-b last:border-0">
              <td className="p-2 font-medium">{p.name}</td>
              <td className="p-2">{p.address}{p.city ? `, ${p.city}` : ''}{p.state ? `, ${p.state}` : ''}</td>
              <td className="p-2">{p.units.length}</td>
              <td className="p-2">{p.owner?.name ?? '—'}</td>
              <td className="p-2">{p._count.tasks}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
