'use client';
import { useEffect, useState } from 'react';
import { ClockButton } from '@/components/ClockButton';
import { format, isSameDay } from 'date-fns';

type Task = {
  id: string;
  title: string;
  type: string;
  status: string;
  scheduledFor: string;
  estimatedMin: number | null;
  notes: string | null;
  property: { name: string };
  unit: { label: string } | null;
};

export default function WorkerPage() {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState(true);

  async function reload() {
    setLoading(true);
    const r = await fetch('/api/schedule');
    const j = await r.json();
    setTasks(j.tasks ?? []);
    setLoading(false);
  }
  useEffect(() => { reload(); }, []);

  async function setStatus(id: string, status: string) {
    await fetch(`/api/tasks/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status })
    });
    reload();
  }

  const today = new Date();
  const todays = tasks.filter(t => isSameDay(new Date(t.scheduledFor), today));
  const rest   = tasks.filter(t => !isSameDay(new Date(t.scheduledFor), today));

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">My schedule</h1>
        <ClockButton />
      </div>

      <section className="mb-6">
        <h2 className="font-semibold mb-2">Today</h2>
        {loading && <div>Loading…</div>}
        {!loading && todays.length === 0 && <div className="text-slate-500 text-sm">Nothing scheduled today.</div>}
        <div className="space-y-2">
          {todays.map(t => (
            <article key={t.id} className="bg-white rounded shadow-sm p-3">
              <div className="flex justify-between">
                <div>
                  <div className="font-medium">{t.title}</div>
                  <div className="text-sm text-slate-600">
                    {t.property.name}{t.unit ? ` • ${t.unit.label}` : ''}
                  </div>
                  <div className="text-sm text-slate-500">
                    {format(new Date(t.scheduledFor), 'EEE h:mm a')} • {t.estimatedMin ?? '?'} min • {t.status}
                  </div>
                </div>
                <div className="flex gap-2">
                  {t.status !== 'IN_PROGRESS' && t.status !== 'COMPLETED' && (
                    <button onClick={() => setStatus(t.id, 'IN_PROGRESS')} className="bg-amber-500 text-white px-3 py-1 rounded text-sm">Start</button>
                  )}
                  {t.status !== 'COMPLETED' && (
                    <button onClick={() => setStatus(t.id, 'COMPLETED')} className="bg-emerald-600 text-white px-3 py-1 rounded text-sm">Done</button>
                  )}
                </div>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section>
        <h2 className="font-semibold mb-2">Rest of the week</h2>
        <div className="space-y-2">
          {rest.map(t => (
            <article key={t.id} className="bg-white rounded shadow-sm p-3 text-sm">
              <div className="flex justify-between">
                <div>
                  <span className="font-medium">{t.title}</span>
                  <span className="text-slate-600"> — {t.property.name}{t.unit ? ` • ${t.unit.label}` : ''}</span>
                </div>
                <div className="text-slate-500">{format(new Date(t.scheduledFor), 'EEE h:mm a')}</div>
              </div>
            </article>
          ))}
          {rest.length === 0 && <div className="text-slate-500 text-sm">—</div>}
        </div>
      </section>
    </div>
  );
}
