import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { redirect } from 'next/navigation';
import { NavBar } from '@/components/NavBar';

export default async function WorkerLayout({ children }: { children: React.ReactNode }) {
  const session = await getServerSession(authOptions);
  if (!session) redirect('/login');
  const role = (session.user as any).role;
  if (role !== 'CLEANER' && role !== 'PORTER') redirect('/');
  return (
    <>
      <NavBar />
      <main className="max-w-5xl mx-auto px-4 py-6">{children}</main>
    </>
  );
}
