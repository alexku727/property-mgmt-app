'use client';
import { useState } from 'react';
import { signIn } from 'next-auth/react';
import { useRouter } from 'next/navigation';

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true); setError('');
    const res = await signIn('credentials', { email, password, redirect: false });
    setLoading(false);
    if (res?.error) { setError('Invalid email or password'); return; }
    router.push('/');
    router.refresh();
  }

  return (
    <main className="min-h-screen flex items-center justify-center">
      <form onSubmit={onSubmit} className="bg-white rounded-xl shadow p-8 w-full max-w-sm">
        <h1 className="text-xl font-bold mb-6">Sign in</h1>
        <label className="block text-sm mb-1">Email</label>
        <input className="border rounded w-full px-3 py-2 mb-4" type="email"
          value={email} onChange={e => setEmail(e.target.value)} required />
        <label className="block text-sm mb-1">Password</label>
        <input className="border rounded w-full px-3 py-2 mb-4" type="password"
          value={password} onChange={e => setPassword(e.target.value)} required />
        {error && <div className="text-red-600 text-sm mb-3">{error}</div>}
        <button disabled={loading} className="bg-brand text-white w-full py-2 rounded hover:bg-brand-dark disabled:opacity-60">
          {loading ? 'Signing in…' : 'Sign in'}
        </button>
        <p className="text-xs text-slate-500 mt-4">
          Seeded accounts: admin / cleaner / porter / owner @example.com (pw: changeme123)
        </p>
      </form>
    </main>
  );
}
