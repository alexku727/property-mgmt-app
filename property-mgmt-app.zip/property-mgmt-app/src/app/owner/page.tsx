'use client';
import { useEffect, useState } from 'react';

type Invoice = {
  id: string; number: string; status: string;
  totalCents: number; issuedAt: string; dueAt: string | null;
  property?: { name: string } | null;
  lines: { description: string; amountCents: number }[];
};

export default function OwnerPage() {
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [busy, setBusy] = useState<string | null>(null);

  async function reload() {
    const r = await fetch('/api/billing/invoices');
    setInvoices(await r.json());
  }
  useEffect(() => { reload(); }, []);

  async function pay(id: string) {
    setBusy(id);
    const res = await fetch('/api/billing/checkout', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ invoiceId: id })
    });
    setBusy(null);
    if (!res.ok) return alert('Could not start checkout');
    const { url } = await res.json();
    location.href = url;
  }

  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">My invoices</h1>
      <div className="space-y-3">
        {invoices.length === 0 && <div className="text-slate-500 text-sm">No invoices yet.</div>}
        {invoices.map(inv => (
          <article key={inv.id} className="bg-white rounded shadow-sm p-4">
            <div className="flex justify-between items-start">
              <div>
                <div className="font-mono text-sm text-slate-600">{inv.number}</div>
                <div className="font-semibold text-lg">${(inv.totalCents / 100).toFixed(2)}</div>
                <div className="text-sm text-slate-500">
                  Issued {new Date(inv.issuedAt).toLocaleDateString()}
                  {inv.dueAt ? ` • Due ${new Date(inv.dueAt).toLocaleDateString()}` : ''}
                  {inv.property ? ` • ${inv.property.name}` : ''}
                </div>
              </div>
              <div className="text-right">
                <div className={`text-xs uppercase font-semibold mb-2 ${inv.status === 'PAID' ? 'text-emerald-600' : 'text-amber-600'}`}>
                  {inv.status}
                </div>
                {inv.status !== 'PAID' && (
                  <button disabled={busy === inv.id} onClick={() => pay(inv.id)}
                    className="bg-brand text-white px-3 py-2 rounded text-sm disabled:opacity-60">
                    {busy === inv.id ? 'Starting…' : 'Pay with card'}
                  </button>
                )}
              </div>
            </div>
            <ul className="mt-3 text-sm text-slate-700 space-y-0.5">
              {inv.lines.map((l, ix) => (
                <li key={ix} className="flex justify-between">
                  <span>{l.description}</span>
                  <span>${(l.amountCents / 100).toFixed(2)}</span>
                </li>
              ))}
            </ul>
          </article>
        ))}
      </div>
    </div>
  );
}
