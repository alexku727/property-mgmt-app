/**
 * BookingKoala webhook receiver.
 *
 * Configure in BookingKoala: Settings → Integrations → Webhooks
 *   URL:    https://YOUR_DOMAIN/api/webhooks/bookingkoala
 *   Events: booking.created, booking.updated, booking.cancelled
 *   Header: X-Webhook-Secret = (value of BOOKINGKOALA_WEBHOOK_SECRET)
 *
 * If your BookingKoala plan does not expose webhooks directly, you can
 * relay the same payload via Zapier or Make (Integromat) → this endpoint.
 */
import { NextRequest, NextResponse } from 'next/server';
import { mapBooking } from '@/lib/bookingkoala';
import { persistTasks } from '@/lib/sync';
import { TaskSource } from '@prisma/client';
import { prisma } from '@/lib/prisma';

export const dynamic = 'force-dynamic';

export async function POST(req: NextRequest) {
  const secret = process.env.BOOKINGKOALA_WEBHOOK_SECRET;
  if (secret) {
    const provided = req.headers.get('x-webhook-secret') ?? req.headers.get('x-bookingkoala-secret');
    if (provided !== secret) return NextResponse.json({ error: 'bad_secret' }, { status: 401 });
  }
  const payload = await req.json();
  const event = payload.event ?? payload.type ?? 'booking.updated';
  const booking = payload.data ?? payload.booking ?? payload;

  if (event === 'booking.cancelled' || event === 'booking.deleted') {
    const externalId = String(booking?.id ?? booking?.booking_id ?? '');
    if (externalId) {
      await prisma.task.updateMany({
        where: { externalRef: { source: TaskSource.BOOKINGKOALA, externalId } },
        data: { status: 'CANCELLED' }
      });
    }
    return NextResponse.json({ ok: true });
  }

  const normalized = mapBooking(booking);
  if (!normalized) return NextResponse.json({ ok: true, ignored: true });
  const result = await persistTasks(TaskSource.BOOKINGKOALA, [normalized]);
  return NextResponse.json(result);
}
