import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { Role } from '@prisma/client';

export async function GET() {
  const session = await getServerSession(authOptions);
  if (!session || (session.user as any).role !== Role.ADMIN) {
    return NextResponse.json({ error: 'forbidden' }, { status: 403 });
  }
  const workers = await prisma.user.findMany({
    where: { role: { in: [Role.CLEANER, Role.PORTER] }, active: true },
    select: { id: true, name: true, email: true, role: true }
  });
  return NextResponse.json(workers);
}
