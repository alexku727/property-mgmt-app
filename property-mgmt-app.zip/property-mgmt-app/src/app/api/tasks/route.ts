import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { Role, TaskStatus, TaskType } from '@prisma/client';
import { z } from 'zod';

export const dynamic = 'force-dynamic';

const createSchema = z.object({
  type: z.nativeEnum(TaskType),
  title: z.string().min(1),
  description: z.string().optional(),
  propertyId: z.string(),
  unitId: z.string().optional(),
  scheduledFor: z.string(), // ISO
  estimatedMin: z.number().int().positive().optional(),
  assignedToId: z.string().optional(),
  rate: z.number().nonnegative().optional()
});

export async function GET(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: 'unauthorized' }, { status: 401 });
  const sp = req.nextUrl.searchParams;
  const from = sp.get('from') ? new Date(sp.get('from')!) : undefined;
  const to   = sp.get('to')   ? new Date(sp.get('to')!)   : undefined;
  const user = session.user as any;

  const where: any = {};
  if (from || to) {
    where.scheduledFor = {};
    if (from) where.scheduledFor.gte = from;
    if (to)   where.scheduledFor.lte = to;
  }
  // Workers see only their own tasks
  if (user.role === Role.CLEANER || user.role === Role.PORTER) {
    where.assignedToId = user.id;
  }
  // Owners see only their properties
  if (user.role === Role.OWNER) {
    where.property = { ownerId: user.id };
  }

  const tasks = await prisma.task.findMany({
    where,
    orderBy: { scheduledFor: 'asc' },
    include: { property: true, unit: true, assignedTo: { select: { id: true, name: true, role: true } } }
  });
  return NextResponse.json(tasks);
}

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session || (session.user as any).role !== Role.ADMIN) {
    return NextResponse.json({ error: 'forbidden' }, { status: 403 });
  }
  const body = await req.json();
  const parsed = createSchema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  const data = parsed.data;
  const task = await prisma.task.create({
    data: {
      type: data.type,
      title: data.title,
      description: data.description,
      propertyId: data.propertyId,
      unitId: data.unitId,
      scheduledFor: new Date(data.scheduledFor),
      estimatedMin: data.estimatedMin,
      assignedToId: data.assignedToId,
      status: data.assignedToId ? TaskStatus.ASSIGNED : TaskStatus.UNASSIGNED,
      rate: data.rate
    }
  });
  return NextResponse.json(task, { status: 201 });
}
