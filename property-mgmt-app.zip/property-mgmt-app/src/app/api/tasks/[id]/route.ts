import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { Role, TaskStatus, TaskType } from '@prisma/client';
import { z } from 'zod';

const updateSchema = z.object({
  type: z.nativeEnum(TaskType).optional(),
  title: z.string().optional(),
  description: z.string().nullable().optional(),
  scheduledFor: z.string().optional(),
  estimatedMin: z.number().int().positive().nullable().optional(),
  assignedToId: z.string().nullable().optional(),
  status: z.nativeEnum(TaskStatus).optional(),
  notes: z.string().nullable().optional(),
  rate: z.number().nonnegative().nullable().optional()
});

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: 'unauthorized' }, { status: 401 });
  const user = session.user as any;

  const body = await req.json();
  const parsed = updateSchema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });

  const task = await prisma.task.findUnique({ where: { id: params.id } });
  if (!task) return NextResponse.json({ error: 'not_found' }, { status: 404 });

  // Workers can update status + notes for their own task only
  if (user.role !== Role.ADMIN) {
    if (task.assignedToId !== user.id) return NextResponse.json({ error: 'forbidden' }, { status: 403 });
    const allowed: any = {};
    if (parsed.data.status) allowed.status = parsed.data.status;
    if (parsed.data.notes !== undefined) allowed.notes = parsed.data.notes;
    if (parsed.data.status === TaskStatus.COMPLETED) allowed.completedAt = new Date();
    const updated = await prisma.task.update({ where: { id: params.id }, data: allowed });
    return NextResponse.json(updated);
  }

  // Admin: full update
  const data: any = { ...parsed.data };
  if (data.scheduledFor) data.scheduledFor = new Date(data.scheduledFor);
  if (data.status === TaskStatus.COMPLETED && !task.completedAt) data.completedAt = new Date();
  if (data.assignedToId && task.status === TaskStatus.UNASSIGNED) data.status = TaskStatus.ASSIGNED;
  const updated = await prisma.task.update({ where: { id: params.id }, data });
  return NextResponse.json(updated);
}

export async function DELETE(_req: NextRequest, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions);
  if (!session || (session.user as any).role !== Role.ADMIN) {
    return NextResponse.json({ error: 'forbidden' }, { status: 403 });
  }
  await prisma.task.delete({ where: { id: params.id } });
  return NextResponse.json({ ok: true });
}
