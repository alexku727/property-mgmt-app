import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { Role } from '@prisma/client';
import { weekRange } from '@/lib/dates';

export const dynamic = 'force-dynamic';

/** Returns the current (or selected) week's tasks grouped by day. */
export async function GET(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: 'unauthorized' }, { status: 401 });

  const anchorParam = req.nextUrl.searchParams.get('anchor');
  const anchor = anchorParam ? new Date(anchorParam) : new Date();
  const { start, end } = weekRange(anchor);

  const user = session.user as any;
  const where: any = { scheduledFor: { gte: start, lte: end } };
  if (user.role === Role.CLEANER || user.role === Role.PORTER) where.assignedToId = user.id;
  if (user.role === Role.OWNER) where.property = { ownerId: user.id };

  const tasks = await prisma.task.findMany({
    where,
    orderBy: { scheduledFor: 'asc' },
    include: { property: true, unit: true, assignedTo: { select: { id: true, name: true, role: true } } }
  });

  return NextResponse.json({ start, end, tasks });
}
