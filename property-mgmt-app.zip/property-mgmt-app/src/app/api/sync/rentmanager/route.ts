import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { fetchRentManagerTasks } from '@/lib/rentmanager';
import { persistTasks } from '@/lib/sync';
import { TaskSource } from '@prisma/client';

export const dynamic = 'force-dynamic';

export async function POST() {
  const session = await getServerSession(authOptions);
  if (!session || (session.user as any).role !== 'ADMIN') {
    return NextResponse.json({ error: 'forbidden' }, { status: 403 });
  }
  try {
    const items = await fetchRentManagerTasks();
    const result = await persistTasks(TaskSource.RENT_MANAGER, items);
    return NextResponse.json(result);
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
