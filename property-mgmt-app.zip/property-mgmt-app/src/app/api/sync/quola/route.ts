// DEPRECATED: replaced by /api/sync/bookingkoala. Kept as an alias for now.
import { POST as bkPost } from '../bookingkoala/route';
export const dynamic = 'force-dynamic';
export const POST = bkPost;
