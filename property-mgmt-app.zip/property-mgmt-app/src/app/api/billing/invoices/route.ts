import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { Role, InvoiceStatus } from '@prisma/client';
import { z } from 'zod';

const createSchema = z.object({
  ownerId: z.string(),
  propertyId: z.string().optional(),
  dueAt: z.string().optional(),
  taskIds: z.array(z.string()).default([]),
  taxCents: z.number().int().nonnegative().default(0),
  notes: z.string().optional()
});

export async function GET() {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: 'unauthorized' }, { status: 401 });
  const user = session.user as any;

  const where = user.role === Role.ADMIN ? {} : { ownerId: user.id };
  const invoices = await prisma.invoice.findMany({
    where,
    orderBy: { issuedAt: 'desc' },
    include: { lines: true, property: true, owner: { select: { id: true, name: true, email: true } } }
  });
  return NextResponse.json(invoices);
}

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session || (session.user as any).role !== Role.ADMIN) {
    return NextResponse.json({ error: 'forbidden' }, { status: 403 });
  }
  const body = await req.json();
  const parsed = createSchema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  const data = parsed.data;

  const tasks = await prisma.task.findMany({ where: { id: { in: data.taskIds } } });
  const lines = tasks.map(t => {
    const hours = (t.estimatedMin ?? 60) / 60;
    const rate = Number(t.rate ?? 0);
    const amountCents = Math.round(hours * rate * 100);
    return {
      taskId: t.id,
      description: `${t.title} (${t.scheduledFor.toISOString().slice(0,10)})`,
      quantity: hours,
      unitCents: Math.round(rate * 100),
      amountCents
    };
  });
  const subtotal = lines.reduce((s, l) => s + l.amountCents, 0);
  const total = subtotal + (data.taxCents ?? 0);
  const number = `INV-${Date.now().toString(36).toUpperCase()}`;

  const invoice = await prisma.invoice.create({
    data: {
      number,
      ownerId: data.ownerId,
      propertyId: data.propertyId,
      dueAt: data.dueAt ? new Date(data.dueAt) : null,
      status: InvoiceStatus.SENT,
      subtotalCents: subtotal,
      taxCents: data.taxCents ?? 0,
      totalCents: total,
      notes: data.notes,
      lines: { create: lines }
    },
    include: { lines: true }
  });
  return NextResponse.json(invoice, { status: 201 });
}
