import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { stripe } from '@/lib/stripe';
import { z } from 'zod';

const schema = z.object({ invoiceId: z.string() });

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: 'unauthorized' }, { status: 401 });
  const user = session.user as any;

  const body = await req.json();
  const parsed = schema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });

  const invoice = await prisma.invoice.findUnique({
    where: { id: parsed.data.invoiceId },
    include: { lines: true, owner: true }
  });
  if (!invoice) return NextResponse.json({ error: 'not_found' }, { status: 404 });
  if (user.role !== 'ADMIN' && invoice.ownerId !== user.id) {
    return NextResponse.json({ error: 'forbidden' }, { status: 403 });
  }

  const origin = req.nextUrl.origin;
  const stripeSession = await stripe.checkout.sessions.create({
    mode: 'payment',
    customer_email: invoice.owner.email,
    line_items: invoice.lines.map(l => ({
      price_data: {
        currency: 'usd',
        product_data: { name: l.description },
        unit_amount: l.unitCents
      },
      quantity: Number(l.quantity)
    })),
    metadata: { invoiceId: invoice.id },
    success_url: `${origin}/owner?status=success&invoice=${invoice.id}`,
    cancel_url: `${origin}/owner?status=cancelled&invoice=${invoice.id}`
  });

  await prisma.invoice.update({
    where: { id: invoice.id },
    data: { stripeCheckoutSessionId: stripeSession.id }
  });

  return NextResponse.json({ url: stripeSession.url });
}
