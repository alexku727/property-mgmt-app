import { NextRequest, NextResponse } from 'next/server';
import { stripe } from '@/lib/stripe';
import { prisma } from '@/lib/prisma';
import { InvoiceStatus } from '@prisma/client';

export const dynamic = 'force-dynamic';

export async function POST(req: NextRequest) {
  const sig = req.headers.get('stripe-signature');
  if (!sig || !process.env.STRIPE_WEBHOOK_SECRET) {
    return NextResponse.json({ error: 'no_signature' }, { status: 400 });
  }
  const raw = await req.text();

  let event;
  try {
    event = stripe.webhooks.constructEvent(raw, sig, process.env.STRIPE_WEBHOOK_SECRET);
  } catch (err: any) {
    return NextResponse.json({ error: `bad_signature: ${err.message}` }, { status: 400 });
  }

  if (event.type === 'checkout.session.completed') {
    const s: any = event.data.object;
    const invoiceId = s.metadata?.invoiceId;
    if (invoiceId && s.payment_status === 'paid') {
      await prisma.invoice.update({
        where: { id: invoiceId },
        data: {
          status: InvoiceStatus.PAID,
          paidAt: new Date(),
          stripePaymentIntentId: s.payment_intent ?? null
        }
      });
      await prisma.payment.create({
        data: {
          invoiceId,
          amountCents: s.amount_total ?? 0,
          stripePaymentIntentId: s.payment_intent ?? null,
          status: 'succeeded'
        }
      });
    }
  }

  return NextResponse.json({ received: true });
}
