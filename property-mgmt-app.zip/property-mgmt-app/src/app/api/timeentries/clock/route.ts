import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { z } from 'zod';

const schema = z.object({
  action: z.enum(['in', 'out']),
  taskId: z.string().optional(),
  lat: z.number().optional(),
  lng: z.number().optional(),
  notes: z.string().optional()
});

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: 'unauthorized' }, { status: 401 });
  const user = session.user as any;
  const body = await req.json();
  const parsed = schema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  const { action, taskId, lat, lng, notes } = parsed.data;

  if (action === 'in') {
    // close any open entry first
    await prisma.timeEntry.updateMany({
      where: { userId: user.id, clockOut: null },
      data: { clockOut: new Date() }
    });
    const entry = await prisma.timeEntry.create({
      data: { userId: user.id, taskId: taskId ?? null, clockIn: new Date(), lat, lng, notes }
    });
    if (taskId) {
      await prisma.task.updateMany({
        where: { id: taskId, assignedToId: user.id },
        data: { status: 'IN_PROGRESS' }
      });
    }
    return NextResponse.json(entry);
  }

  // clock out
  const open = await prisma.timeEntry.findFirst({
    where: { userId: user.id, clockOut: null },
    orderBy: { clockIn: 'desc' }
  });
  if (!open) return NextResponse.json({ error: 'no_open_entry' }, { status: 400 });
  const entry = await prisma.timeEntry.update({
    where: { id: open.id },
    data: { clockOut: new Date(), notes: notes ?? open.notes }
  });
  return NextResponse.json(entry);
}
