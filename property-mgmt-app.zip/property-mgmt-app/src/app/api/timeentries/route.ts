import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { Role } from '@prisma/client';

export async function GET(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: 'unauthorized' }, { status: 401 });
  const user = session.user as any;
  const sp = req.nextUrl.searchParams;
  const userIdFilter = sp.get('userId');

  const where: any = {};
  if (user.role === Role.ADMIN) {
    if (userIdFilter) where.userId = userIdFilter;
  } else {
    where.userId = user.id;
  }

  const entries = await prisma.timeEntry.findMany({
    where,
    orderBy: { clockIn: 'desc' },
    take: 100,
    include: { task: { select: { id: true, title: true } }, user: { select: { id: true, name: true } } }
  });
  return NextResponse.json(entries);
}
