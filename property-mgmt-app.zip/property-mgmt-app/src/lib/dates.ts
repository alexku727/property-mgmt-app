import { startOfWeek, endOfWeek, addDays, format } from 'date-fns';

export function weekRange(anchor: Date = new Date()) {
  const start = startOfWeek(anchor, { weekStartsOn: 1 });   // Monday
  const end   = endOfWeek(anchor,   { weekStartsOn: 1 });
  return { start, end };
}

export function dayLabels(start: Date) {
  return Array.from({ length: 7 }, (_, i) => {
    const d = addDays(start, i);
    return { date: d, label: format(d, 'EEE MMM d') };
  });
}
