import { prisma } from './prisma';
import { TaskSource, TaskStatus } from '@prisma/client';
import type { NormalizedTask } from './rentmanager';

export async function persistTasks(source: TaskSource, items: NormalizedTask[]) {
  const run = await prisma.syncRun.create({ data: { source } });
  let upserts = 0;
  try {
    for (const item of items) {
      // Resolve property — create a placeholder if we only have an external id/name
      let property = null as Awaited<ReturnType<typeof prisma.property.findFirst>> | null;
      if (item.propertyExternalId) {
        const ref = await prisma.externalRef.findUnique({
          where: { source_externalId: { source, externalId: `prop:${item.propertyExternalId}` } }
        });
        if (ref?.propertyId) property = await prisma.property.findUnique({ where: { id: ref.propertyId } });
      }
      if (!property) {
        property = await prisma.property.create({
          data: {
            name: item.propertyName ?? `Property ${item.propertyExternalId ?? 'unknown'}`,
            address: 'Unknown',
            externalRefs: item.propertyExternalId
              ? { create: { source, externalId: `prop:${item.propertyExternalId}` } }
              : undefined
          }
        });
      }

      // Upsert task by source+externalId
      const existing = await prisma.externalRef.findUnique({
        where: { source_externalId: { source, externalId: item.externalId } }
      });

      if (existing?.taskId) {
        await prisma.task.update({
          where: { id: existing.taskId },
          data: {
            title: item.title,
            description: item.description,
            scheduledFor: item.scheduledFor,
            estimatedMin: item.estimatedMin ?? null,
            notes: item.notes
          }
        });
      } else {
        const task = await prisma.task.create({
          data: {
            source,
            type: item.type,
            title: item.title,
            description: item.description,
            propertyId: property.id,
            scheduledFor: item.scheduledFor,
            estimatedMin: item.estimatedMin ?? null,
            notes: item.notes,
            status: TaskStatus.UNASSIGNED
          }
        });
        await prisma.externalRef.create({
          data: { source, externalId: item.externalId, taskId: task.id, propertyId: property.id }
        });
      }
      upserts++;
    }
    await prisma.syncRun.update({
      where: { id: run.id },
      data: { ok: true, itemsUpserted: upserts, endedAt: new Date() }
    });
    return { ok: true, itemsUpserted: upserts };
  } catch (err: any) {
    await prisma.syncRun.update({
      where: { id: run.id },
      data: { ok: false, errorText: String(err?.message ?? err), endedAt: new Date() }
    });
    throw err;
  }
}
