/**
 * Rent Manager API client.
 *
 * Rent Manager exposes a RESTful Web API. Each customer has a unique subdomain
 * (e.g. https://yourcompany.api.rentmanager.com). Auth is a short-lived token
 * obtained by POSTing username/password to /Authentication/AuthorizeUser.
 *
 * This module pulls Service Issues / Work Orders and normalizes them into
 * shapes the rest of the app can upsert.
 *
 * IMPORTANT: endpoint paths below follow Rent Manager v12 conventions but
 * exact field names may vary by tenant configuration. Verify against your
 * tenant's API documentation and adjust the field mappings in `mapServiceIssue`.
 */

import { TaskType } from '@prisma/client';

const BASE = process.env.RENTMANAGER_BASE_URL ?? '';

let cachedToken: { token: string; expiresAt: number } | null = null;

async function getToken(): Promise<string> {
  if (cachedToken && cachedToken.expiresAt > Date.now() + 60_000) {
    return cachedToken.token;
  }
  if (!BASE || !process.env.RENTMANAGER_USERNAME) {
    throw new Error('Rent Manager credentials not configured (.env).');
  }
  const res = await fetch(`${BASE}/Authentication/AuthorizeUser`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      Username: process.env.RENTMANAGER_USERNAME,
      Password: process.env.RENTMANAGER_PASSWORD,
      LocationID: process.env.RENTMANAGER_LOCATION_ID ? Number(process.env.RENTMANAGER_LOCATION_ID) : undefined
    })
  });
  if (!res.ok) throw new Error(`Rent Manager auth failed: ${res.status}`);
  const token = (await res.text()).replace(/"/g, '');
  // Tokens last roughly an hour; cache conservatively for 45 min.
  cachedToken = { token, expiresAt: Date.now() + 45 * 60 * 1000 };
  return token;
}

async function rmFetch(path: string, init: RequestInit = {}) {
  const token = await getToken();
  const res = await fetch(`${BASE}${path}`, {
    ...init,
    headers: {
      ...(init.headers ?? {}),
      'X-RM12Api-ApiToken': token,
      Accept: 'application/json',
      'Content-Type': 'application/json'
    }
  });
  if (!res.ok) {
    const body = await res.text();
    throw new Error(`Rent Manager ${path} → ${res.status}: ${body.slice(0, 200)}`);
  }
  return res.json();
}

export interface NormalizedTask {
  externalId: string;
  type: TaskType;
  title: string;
  description?: string;
  propertyExternalId?: string;
  unitExternalId?: string;
  propertyName?: string;
  unitLabel?: string;
  scheduledFor: Date;
  estimatedMin?: number;
  notes?: string;
}

/**
 * Pull recent open Service Issues (work orders) from Rent Manager.
 * Filters: open status, scheduled in the next 30 days.
 */
export async function fetchRentManagerTasks(): Promise<NormalizedTask[]> {
  // Rent Manager v12 typically exposes /ServiceIssues
  // Query syntax: ?filters=Status,eq,Open&embeds=Property,Unit
  const path = '/ServiceIssues?filters=Status,neq,Closed&embeds=Property,Unit&pagesize=200';
  const data = await rmFetch(path);
  const items: any[] = Array.isArray(data) ? data : (data?.value ?? []);
  return items.map(mapServiceIssue).filter(Boolean) as NormalizedTask[];
}

function mapServiceIssue(si: any): NormalizedTask | null {
  if (!si) return null;
  const id = si.ServiceIssueID ?? si.ID ?? si.id;
  if (!id) return null;
  const title: string = si.Brief ?? si.Description ?? `Work order ${id}`;
  const desc: string | undefined = si.Description;
  const scheduled =
    si.ServiceScheduleDate ?? si.CreateDate ?? si.OpenDate ?? new Date().toISOString();
  const property = si.Property ?? {};
  const unit = si.Unit ?? {};
  const category: string = (si.Category?.Name ?? si.Category ?? '').toLowerCase();
  const type: TaskType = /clean|housekeep|turnover/.test(category)
    ? TaskType.CLEANING
    : /porter|trash|grounds|sweep/.test(category)
      ? TaskType.PORTER
      : TaskType.MAINTENANCE;
  return {
    externalId: String(id),
    type,
    title,
    description: desc,
    propertyExternalId: property?.PropertyID ? String(property.PropertyID) : undefined,
    unitExternalId: unit?.UnitID ? String(unit.UnitID) : undefined,
    propertyName: property?.Name ?? property?.ShortName,
    unitLabel: unit?.Name ?? unit?.UnitNumber,
    scheduledFor: new Date(scheduled),
    estimatedMin: si.EstimatedDuration ? Number(si.EstimatedDuration) : undefined,
    notes: si.Comments
  };
}
