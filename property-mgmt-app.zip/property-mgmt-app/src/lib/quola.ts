// DEPRECATED: This file used to hold the Quola connector.
// The second source site is BookingKoala — see src/lib/bookingkoala.ts.
// This file is kept only to avoid breaking imports; please remove it.
export { fetchBookingKoalaTasks as fetchQuolaTasks } from './bookingkoala';
