import Stripe from 'stripe';

if (!process.env.STRIPE_SECRET_KEY) {
  // Allow build without key but log at runtime
  console.warn('STRIPE_SECRET_KEY is not set — billing endpoints will fail until configured.');
}

export const stripe = new Stripe(process.env.STRIPE_SECRET_KEY ?? 'sk_test_placeholder', {
  apiVersion: '2025-02-24.acacia'
});

export const STRIPE_PUBLISHABLE_KEY = process.env.STRIPE_PUBLISHABLE_KEY ?? '';
