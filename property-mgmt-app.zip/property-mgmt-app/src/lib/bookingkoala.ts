/**
 * BookingKoala API client.
 *
 * BookingKoala is a booking platform for service businesses (cleaning, etc.).
 * Auth: API key generated in your BookingKoala account → Settings → Integrations.
 * The base URL is your account's subdomain, e.g. https://yourcompany.bookingkoala.com.
 *
 * NOTE: BookingKoala's full REST reference is provided privately to API customers.
 * The endpoint/field names below follow the conventions documented in their Zapier
 * and Make integrations. If your API key is rejected or fields look different,
 * adjust `BOOKING_LIST_PATH` and `mapBooking` to match the response your account
 * returns. Use `console.log(JSON.stringify(data, null, 2))` in fetchFromRest to
 * inspect the actual shape.
 */

import { TaskType } from '@prisma/client';
import type { NormalizedTask } from './rentmanager';

const BASE   = (process.env.BOOKINGKOALA_BASE_URL ?? '').replace(/\/+$/, '');
const APIKEY = process.env.BOOKINGKOALA_API_KEY ?? '';

const BOOKING_LIST_PATH = '/api/v1/bookings'; // adjust if your account uses a different path

export async function fetchBookingKoalaTasks(opts: { sinceDays?: number } = {}): Promise<NormalizedTask[]> {
  if (!BASE || !APIKEY) {
    throw new Error('BookingKoala not configured. Set BOOKINGKOALA_BASE_URL + BOOKINGKOALA_API_KEY in .env.');
  }
  const since = new Date();
  since.setDate(since.getDate() - (opts.sinceDays ?? 0));
  const until = new Date();
  until.setDate(until.getDate() + 30);

  const url = new URL(BASE + BOOKING_LIST_PATH);
  url.searchParams.set('status', 'confirmed');
  url.searchParams.set('start_date', since.toISOString().slice(0, 10));
  url.searchParams.set('end_date',   until.toISOString().slice(0, 10));

  const res = await fetch(url.toString(), {
    headers: {
      'Authorization': `Bearer ${APIKEY}`,
      // BookingKoala has also been observed using a custom header in some accounts:
      'X-API-KEY': APIKEY,
      'Accept': 'application/json'
    }
  });
  if (!res.ok) {
    const body = await res.text();
    throw new Error(`BookingKoala ${res.status}: ${body.slice(0, 200)}`);
  }
  const data = await res.json();
  const items: any[] = Array.isArray(data) ? data : (data.bookings ?? data.data ?? data.results ?? []);
  return items.map(mapBooking).filter(Boolean) as NormalizedTask[];
}

export function mapBooking(b: any): NormalizedTask | null {
  if (!b) return null;
  const id = b.id ?? b.booking_id ?? b.uuid;
  if (!id) return null;

  // Service name often tells you cleaning vs porter
  const serviceName: string = (b.service?.name ?? b.service_name ?? b.service ?? '').toString().toLowerCase();
  const type: TaskType =
    /porter|trash|move|haul/.test(serviceName) ? TaskType.PORTER :
    /clean|housekeep|maid|turnover/.test(serviceName) ? TaskType.CLEANING :
    TaskType.CLEANING;

  // Scheduled time — BookingKoala typically returns ISO start datetime or split date+time
  const scheduled = b.start_datetime
    ?? b.scheduled_at
    ?? (b.date && b.time ? `${b.date}T${b.time}` : null)
    ?? b.created_at;

  // Address → store as property name+address
  const addr = b.address ?? b.customer?.address ?? b.location ?? {};
  const propertyName =
    b.property_name
    ?? addr.label
    ?? [addr.street, addr.city].filter(Boolean).join(', ')
    ?? b.customer?.name
    ?? `Booking ${id}`;

  // Provider (the cleaner/porter assigned in BookingKoala, if any)
  const assignee = b.provider?.name ?? b.team?.name ?? null;

  return {
    externalId: String(id),
    type,
    title: `${b.service?.name ?? serviceName ?? 'Service'} — ${b.customer?.first_name ?? ''} ${b.customer?.last_name ?? ''}`.trim(),
    description: b.notes ?? b.customer_notes ?? undefined,
    propertyExternalId: addr.id ? String(addr.id) : undefined,
    propertyName,
    scheduledFor: new Date(scheduled ?? Date.now()),
    estimatedMin: b.duration_minutes ?? b.duration ?? undefined,
    notes: assignee ? `Assigned in BookingKoala to: ${assignee}` : undefined
  };
}
