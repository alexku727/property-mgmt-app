import { fetchRentManagerTasks } from '../src/lib/rentmanager';
import { fetchBookingKoalaTasks } from '../src/lib/bookingkoala';
import { persistTasks } from '../src/lib/sync';
import { TaskSource } from '@prisma/client';

async function main() {
  console.log('Syncing Rent Manager…');
  try {
    const rm = await fetchRentManagerTasks();
    const r1 = await persistTasks(TaskSource.RENT_MANAGER, rm);
    console.log(`  ✓ ${r1.itemsUpserted} items`);
  } catch (e: any) { console.error('  ✗', e.message); }

  console.log('Syncing BookingKoala…');
  try {
    const b = await fetchBookingKoalaTasks();
    const r2 = await persistTasks(TaskSource.BOOKINGKOALA, b);
    console.log(`  ✓ ${r2.itemsUpserted} items`);
  } catch (e: any) { console.error('  ✗', e.message); }
}
main().then(() => process.exit(0));
