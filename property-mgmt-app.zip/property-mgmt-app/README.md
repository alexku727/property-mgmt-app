# Property Management App

A full-stack web app for a property management company:

- **Pulls cleaning + porter tasks** from **Rent Manager** and **BookingKoala**.
- Produces a **weekly calendar schedule** that admins can edit (assign workers, reschedule, delete).
- Gives **cleaners and porters** their own dashboard with **clock in / clock out** (and optional geolocation).
- **Bills property owners** with credit-card payments via **Stripe Checkout** (Stripe hosts the card form, so you're PCI-compliant).

Built with **Next.js 14 (App Router) + TypeScript + Tailwind + Prisma + PostgreSQL + NextAuth + Stripe**.

---

## Easiest path to a live URL (no servers to manage)

If this is your first app, deploy on **Vercel + Neon**. Both free to start, all browser-based, no Linux/SSH.

1. **GitHub** — create a free account, click "New repository", name it `property-mgmt-app`, drop the contents of this zip in.
2. **Neon** — sign up at neon.tech, create a project, copy the Postgres connection string.
3. **Vercel** — sign up at vercel.com with your GitHub account → "Add New Project" → pick `property-mgmt-app`.
   Add environment variables (see `.env.example` for the full list — at minimum: `DATABASE_URL`, `NEXTAUTH_SECRET`, `NEXTAUTH_URL`).
4. After first deploy, run the DB migration:
   - Vercel Dashboard → your project → Storage tab → Open Neon SQL Editor.
   - In a terminal locally: `npx prisma migrate dev` once with `DATABASE_URL` set to your Neon URL — that creates the tables.
   - Alternatively, `npx prisma migrate deploy` from any machine.

You now have a real URL like `https://property-mgmt-app.vercel.app`. Done.

---

## Local development

```bash
npm install
cp .env.example .env
# edit .env

npx prisma migrate dev --name init
npm run db:seed
npm run dev
# open http://localhost:3000
```

### Seeded accounts (password: `changeme123`)

| Email | Role |
|---|---|
| admin@example.com   | ADMIN   |
| cleaner@example.com | CLEANER |
| porter@example.com  | PORTER  |
| owner@example.com   | OWNER   |

---

## Architecture

```
src/
  app/
    api/
      auth/[...nextauth]/route.ts     — NextAuth credentials provider
      tasks/route.ts + [id]/route.ts  — CRUD for tasks (role-aware)
      schedule/route.ts               — Weekly schedule (role-filtered)
      timeentries/route.ts            — Time-entry list
      timeentries/clock/route.ts      — Clock in / out
      workers/route.ts                — Admin: list cleaners + porters
      sync/rentmanager/route.ts       — Pull from Rent Manager
      sync/bookingkoala/route.ts      — Pull from BookingKoala (poll)
      webhooks/bookingkoala/route.ts  — Receive BookingKoala push events
      billing/invoices/route.ts       — Invoice CRUD
      billing/checkout/route.ts       — Create Stripe Checkout session
      billing/webhook/route.ts        — Stripe webhook → mark paid
    admin/                            — Dashboard, schedule, workers, properties, billing
    worker/                           — Cleaner/porter dashboard with clock in/out
    owner/                            — Property owner invoice + pay flow
    login/                            — Sign-in page
  components/
    NavBar.tsx
    Calendar.tsx                      — Weekly grid, admin-editable
    ClockButton.tsx                   — Clock in / out with geolocation
  lib/
    prisma.ts                         — Singleton Prisma client
    auth.ts                           — NextAuth config + role helpers
    stripe.ts                         — Stripe client
    rentmanager.ts                    — Rent Manager API client (token + work orders)
    bookingkoala.ts                   — BookingKoala API client + payload mapper
    sync.ts                           — Normalize + upsert pulled tasks
    dates.ts                          — Week-range helpers
prisma/
  schema.prisma                       — User, Property, Unit, Task, TimeEntry, Invoice, Payment, SyncRun
  seed.ts                             — Demo accounts + tasks
scripts/
  sync-all.ts                         — CLI sync runner (cron-friendly)
```

### Role-based access

- **ADMIN** — Full read/write across the app.
- **CLEANER / PORTER** — See only their own tasks; can mark status + clock in/out.
- **OWNER** — See only their own invoices, pay via Stripe.

Enforced server-side in every API route.

---

## Integrations

### Rent Manager

[Rent Manager Web API](https://www.rentmanager.com/api-partner-periodical/) — RESTful, per-tenant subdomain, token-authenticated.

`.env`:
```
RENTMANAGER_BASE_URL=https://yourcompany.api.rentmanager.com
RENTMANAGER_USERNAME=...
RENTMANAGER_PASSWORD=...
RENTMANAGER_LOCATION_ID=1
```

Trigger a sync: Admin → Dashboard → **Sync Rent Manager** button. Or `POST /api/sync/rentmanager`. Or cron `npm run sync:all`.

### BookingKoala

Two modes — use either or both:

**Mode A: Poll BookingKoala on a schedule**

`.env`:
```
BOOKINGKOALA_BASE_URL=https://yourcompany.bookingkoala.com
BOOKINGKOALA_API_KEY=<from Settings → Integrations → API>
```

Trigger: Admin → Dashboard → **Sync BookingKoala** button. Or `POST /api/sync/bookingkoala`. Or cron `npm run sync:all`.

**Mode B: Have BookingKoala push events to you (recommended)**

Real-time. No polling.

1. In BookingKoala → Settings → Integrations → Webhooks (or via Zapier/Make if your plan doesn't have native webhooks).
2. Set the URL to `https://YOUR_DOMAIN/api/webhooks/bookingkoala`.
3. Subscribe to `booking.created`, `booking.updated`, `booking.cancelled`.
4. Set the `X-Webhook-Secret` header to a random string; put the same value in `BOOKINGKOALA_WEBHOOK_SECRET` in `.env`.

> **Verify the response shape.** BookingKoala provides full API docs privately to API customers. If your first sync returns 0 items, log the raw response in `src/lib/bookingkoala.ts:fetchBookingKoalaTasks` and adjust the field mapping in `mapBooking` to match.

### Stripe

1. Create a Stripe account, grab test keys.
2. Set `STRIPE_SECRET_KEY` + `STRIPE_PUBLISHABLE_KEY` in `.env`.
3. For webhooks (mark invoices paid):
   - Local: `stripe listen --forward-to localhost:3000/api/billing/webhook`. Copy the `whsec_…` into `STRIPE_WEBHOOK_SECRET`.
   - Production: In Stripe Dashboard, add an endpoint at `https://YOUR_DOMAIN/api/billing/webhook` for `checkout.session.completed`.

---

## Deployment — AWS Lightsail (or DigitalOcean Droplet, or EC2)

If you'd rather run on a real Linux VM than Vercel.

### 1. Provision

- AWS Lightsail or DO Droplet — Ubuntu 22.04, 2 GB RAM. Open ports 22, 80, 443.

### 2. Runtimes

```bash
sudo apt update && sudo apt install -y curl git nginx
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs
sudo npm i -g pm2
```

### 3. PostgreSQL

Lightsail Managed Database, DO Managed Postgres, AWS RDS, or local:
```bash
sudo apt install -y postgresql
sudo -u postgres createuser appuser -P
sudo -u postgres createdb property_mgmt -O appuser
```

### 4. Deploy

```bash
git clone YOUR_REPO /opt/property-mgmt
cd /opt/property-mgmt
npm ci
cp .env.example .env   # then edit .env
npx prisma migrate deploy
npm run build
pm2 start npm --name property-mgmt -- start
pm2 save && pm2 startup
```

### 5. Nginx + HTTPS

`/etc/nginx/sites-available/property-mgmt`:
```nginx
server {
  server_name your.domain.com;
  location / {
    proxy_pass http://127.0.0.1:3000;
    proxy_set_header Host $host;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
  }
}
```
```bash
sudo ln -s /etc/nginx/sites-available/property-mgmt /etc/nginx/sites-enabled/
sudo apt install -y certbot python3-certbot-nginx
sudo certbot --nginx -d your.domain.com
sudo systemctl reload nginx
```

### 6. Periodic sync

```bash
crontab -e
*/15 * * * * cd /opt/property-mgmt && /usr/bin/npm run sync:all >> /var/log/sync.log 2>&1
```

---

## Pre-launch checklist

- [ ] Rotate `NEXTAUTH_SECRET` (`openssl rand -base64 32`).
- [ ] Restrict Postgres to private network only.
- [ ] Set `NEXTAUTH_URL` to your real HTTPS origin.
- [ ] Use Stripe **live** keys + a properly-configured webhook secret.
- [ ] HTTPS everywhere.
- [ ] Change seeded passwords (or remove seed users in production).
- [ ] Confirm Rent Manager + BookingKoala service accounts have read-only scope.

---

## Roadmap (good follow-ups)

- Password reset / invite via NextAuth email provider.
- Drag-and-drop calendar (`dnd-kit`).
- SMS / email notifications (Twilio, SendGrid) on task assignment, completion, payment.
- Multi-tenancy (`Organization` model + scoped queries) if you onboard multiple companies.
