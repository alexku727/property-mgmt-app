import { PrismaClient, Role } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  const passwordHash = await bcrypt.hash('changeme123', 10);

  const admin = await prisma.user.upsert({
    where: { email: 'admin@example.com' },
    update: {},
    create: {
      email: 'admin@example.com',
      name: 'Admin',
      passwordHash,
      role: Role.ADMIN
    }
  });

  const cleaner = await prisma.user.upsert({
    where: { email: 'cleaner@example.com' },
    update: {},
    create: {
      email: 'cleaner@example.com',
      name: 'Casey Cleaner',
      passwordHash,
      role: Role.CLEANER
    }
  });

  const porter = await prisma.user.upsert({
    where: { email: 'porter@example.com' },
    update: {},
    create: {
      email: 'porter@example.com',
      name: 'Pat Porter',
      passwordHash,
      role: Role.PORTER
    }
  });

  const owner = await prisma.user.upsert({
    where: { email: 'owner@example.com' },
    update: {},
    create: {
      email: 'owner@example.com',
      name: 'Olivia Owner',
      passwordHash,
      role: Role.OWNER
    }
  });

  const property = await prisma.property.upsert({
    where: { id: 'demo-property-1' },
    update: {},
    create: {
      id: 'demo-property-1',
      name: 'Maple Court Apartments',
      address: '123 Maple St',
      city: 'Brooklyn',
      state: 'NY',
      zip: '11201',
      ownerId: owner.id,
      units: {
        create: [
          { label: 'Apt 1A' },
          { label: 'Apt 2B' },
          { label: 'Apt 3C' }
        ]
      }
    },
    include: { units: true }
  });

  // Sample tasks across this week
  const today = new Date();
  const tasks = [
    { dayOffset: 0, type: 'CLEANING', title: 'Turn-over clean Apt 1A', assignedToId: cleaner.id },
    { dayOffset: 1, type: 'PORTER', title: 'Trash + lobby sweep', assignedToId: porter.id },
    { dayOffset: 2, type: 'CLEANING', title: 'Common area deep clean', assignedToId: cleaner.id },
    { dayOffset: 3, type: 'PORTER', title: 'Package delivery rounds', assignedToId: porter.id }
  ] as const;

  for (const t of tasks) {
    const scheduledFor = new Date(today);
    scheduledFor.setDate(scheduledFor.getDate() + t.dayOffset);
    scheduledFor.setHours(9, 0, 0, 0);
    await prisma.task.create({
      data: {
        type: t.type as any,
        title: t.title,
        propertyId: property.id,
        scheduledFor,
        estimatedMin: 90,
        status: 'ASSIGNED',
        assignedToId: t.assignedToId,
        rate: 45.0
      }
    });
  }

  console.log('Seed complete. Login with any of:');
  console.log('  admin@example.com / changeme123');
  console.log('  cleaner@example.com / changeme123');
  console.log('  porter@example.com / changeme123');
  console.log('  owner@example.com / changeme123');
}

main().catch(e => { console.error(e); process.exit(1); }).finally(() => prisma.$disconnect());
